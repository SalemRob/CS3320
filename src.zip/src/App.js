import React, { useState, useEffect } from 'react';
import { fetchAvailableBooks } from './api'; // Import the API utility for fetching books
import './App.css'; // Ensure you have this for your styles (if any)

function App() {
  const [books, setBooks] = useState([]); // State to store books
  const [isLoading, setIsLoading] = useState(true); // State to handle loading
  const [error, setError] = useState(''); // State to handle errors

  // Fetch books when the component mounts
  useEffect(() => {
    const loadBooks = async () => {
      try {
        const data = await fetchAvailableBooks(); // Fetch books using the API function
        setBooks(data); // Store the fetched books in state
      } catch (err) {
        console.error('Error fetching books:', err);
        setError('Failed to load books. Please try again later.');
      } finally {
        setIsLoading(false); // Set loading to false
      }
    };

    loadBooks(); // Call the function to fetch books
  }, []); // Empty dependency array ensures this runs once when the component mounts

  return (
    <div className="App">
      <header className="App-header">
        <h1>Library Book Tracker</h1>
      </header>
      <main>
        <h2>Available Books</h2>
        {isLoading ? (
          <p>Loading books...</p>
        ) : error ? (
          <p style={{ color: 'red' }}>{error}</p>
        ) : books.length === 0 ? (
          <p>No books available for checkout.</p>
        ) : (
          <ul>
            {books.map((book) => (
              <li key={book.isbn}>
                <strong>{book.title}</strong> by {book.author}
              </li>
            ))}
          </ul>
        )}
      </main>
    </div>
  );
}

export default App;
