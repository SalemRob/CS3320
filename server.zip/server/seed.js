const mongoose = require('mongoose');
const Book = require('./models/Book');

mongoose.connect('mongodb://127.0.0.1:27017/library', { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log('Connected to MongoDB for seeding'))
  .catch(err => console.error('Connection error:', err));

const seedBooks = async () => {
  await Book.deleteMany(); // Clear existing books
  const books = [
    { title: 'Book 1', author: 'Author 1', publisher: 'Publisher 1', isbn: '1234567890' },
    { title: 'Book 2', author: 'Author 2', publisher: 'Publisher 2', isbn: '1234567891' },
    { title: 'Book 3', author: 'Author 3', publisher: 'Publisher 3', isbn: '1234567892' },
    { title: 'Book 4', author: 'Author 4', publisher: 'Publisher 4', isbn: '1234567893' },
    { title: 'Book 5', author: 'Author 5', publisher: 'Publisher 5', isbn: '1234567894' },
    { title: 'Book 6', author: 'Author 6', publisher: 'Publisher 6', isbn: '1234567895' },
    { title: 'Book 7', author: 'Author 7', publisher: 'Publisher 7', isbn: '1234567896' },
    { title: 'Book 8', author: 'Author 8', publisher: 'Publisher 8', isbn: '1234567897' },
    { title: 'Book 9', author: 'Author 9', publisher: 'Publisher 9', isbn: '1234567898' },
    { title: 'Book 10', author: 'Author 10', publisher: 'Publisher 10', isbn: '1234567899' },
  ];
  await Book.insertMany(books);
  console.log('Seed data added!');
  mongoose.connection.close();
};

seedBooks();
