import axios from 'axios';

// Configure Axios to point to your backend
const api = axios.create({
  baseURL: 'http://localhost:5000', // Backend URL
});

// Fetch available books
export const fetchAvailableBooks = async () => {
  const response = await api.get('/books/available');
  return response.data;
};

// Other endpoints can be added here, e.g., check out a book, return a book
